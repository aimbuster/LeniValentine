# Instructions to use:
To replace the photos, got to the assets folder and replace the "valentine-number.png" photos with files named in the EXACT same way. That means the same capitalization, the same filtype (.png), everything.

I hosted it for free with netlify. It was super easy, just look it up.
